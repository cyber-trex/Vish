/**
 * Vish Player Audio Synthesizer Engine
 * Synthesizes high-fidelity multi-layered music offline via Web Audio OfflineAudioContext
 * and encodes directly to clean WAV Blobs with zero network overhead.
 */

export interface SynthPreset {
  id: string;
  title: string;
  artist: string;
  album: string;
  genre: string;
  bpm: number;
  durationSec: number;
  coverUrl: string;
  lyrics: string[];
}

export function audioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;

  const length = buffer.length * blockAlign;
  const headerByteLength = 44;
  const arrayBuffer = new ArrayBuffer(headerByteLength + length);
  const view = new DataView(arrayBuffer);

  /* RIFF identifier */
  writeString(view, 0, 'RIFF');
  /* RIFF chunk length */
  view.setUint32(4, 36 + length, true);
  /* RIFF type */
  writeString(view, 8, 'WAVE');
  /* format chunk identifier */
  writeString(view, 12, 'fmt ');
  /* format chunk length */
  view.setUint32(16, 16, true);
  /* sample format (raw) */
  view.setUint16(20, format, true);
  /* channel count */
  view.setUint16(22, numChannels, true);
  /* sample rate */
  view.setUint32(24, sampleRate, true);
  /* byte rate (sample rate * block align) */
  view.setUint32(28, sampleRate * blockAlign, true);
  /* block align (channel count * bytes per sample) */
  view.setUint16(32, blockAlign, true);
  /* bits per sample */
  view.setUint16(34, bitDepth, true);
  /* data chunk identifier */
  writeString(view, 36, 'data');
  /* data chunk length */
  view.setUint32(40, length, true);

  // Interleave channels & write 16-bit PCM
  const channels: Float32Array[] = [];
  for (let c = 0; c < numChannels; c++) {
    channels.push(buffer.getChannelData(c));
  }

  let offset = 44;
  for (let i = 0; i < buffer.length; i++) {
    for (let c = 0; c < numChannels; c++) {
      let sample = channels[c][i];
      // Clamp sample between -1 and 1
      sample = Math.max(-1, Math.min(1, sample));
      // Convert to 16-bit integer
      const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      view.setInt16(offset, intSample, true);
      offset += 2;
    }
  }

  return new Blob([view], { type: 'audio/wav' });
}

function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

// Frequencies for musical notes
const NOTE_FREQ: Record<string, number> = {
  C2: 65.41, D2: 73.42, E2: 82.41, F2: 87.31, G2: 98.00, A2: 110.00, B2: 123.47,
  C3: 130.81, D3: 146.83, E3: 164.81, F3: 174.61, G3: 196.00, A3: 220.00, B3: 246.94,
  C4: 261.63, D4: 293.66, E4: 329.63, F4: 349.23, G4: 392.00, A4: 440.00, B4: 493.88,
  C5: 523.25, D5: 587.33, E5: 659.25, F5: 698.46, G5: 783.99, A5: 880.00, B5: 987.77,
};

export async function synthesizeOfflineTrack(preset: SynthPreset): Promise<Blob> {
  const sampleRate = 44100;
  const duration = preset.durationSec;
  const ctx = new OfflineAudioContext(2, sampleRate * duration, sampleRate);

  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0.85, 0);

  // Dynamics Compressor for studio polish
  const compressor = ctx.createDynamicsCompressor();
  compressor.threshold.setValueAtTime(-18, 0);
  compressor.knee.setValueAtTime(30, 0);
  compressor.ratio.setValueAtTime(4, 0);
  compressor.attack.setValueAtTime(0.003, 0);
  compressor.release.setValueAtTime(0.25, 0);

  masterGain.connect(compressor);
  compressor.connect(ctx.destination);

  const beatSec = 60 / preset.bpm;

  if (preset.id === 'synthwave') {
    // Synthwave arrangement
    renderSynthwave(ctx, masterGain, beatSec, duration);
  } else if (preset.id === 'lofi') {
    // Lofi ambient arrangement
    renderLofi(ctx, masterGain, beatSec, duration);
  } else {
    // Vish Signature Futuristic Soundscape
    renderVishSignature(ctx, masterGain, beatSec, duration);
  }

  const renderedBuffer = await ctx.startRendering();
  return audioBufferToWavBlob(renderedBuffer);
}

function renderSynthwave(ctx: OfflineAudioContext, out: AudioNode, beat: number, totalDur: number) {
  const chords = [
    [NOTE_FREQ.A2, NOTE_FREQ.C3, NOTE_FREQ.E3, NOTE_FREQ.A3],
    [NOTE_FREQ.F2, NOTE_FREQ.A2, NOTE_FREQ.C3, NOTE_FREQ.F3],
    [NOTE_FREQ.C3, NOTE_FREQ.E3, NOTE_FREQ.G3, NOTE_FREQ.C4],
    [NOTE_FREQ.G2, NOTE_FREQ.B2, NOTE_FREQ.D3, NOTE_FREQ.G3],
  ];

  const leadNotes = [
    NOTE_FREQ.E4, NOTE_FREQ.G4, NOTE_FREQ.A4, NOTE_FREQ.C5,
    NOTE_FREQ.B4, NOTE_FREQ.A4, NOTE_FREQ.G4, NOTE_FREQ.E4
  ];

  // 1. Kick drum every beat
  for (let t = 0; t < totalDur; t += beat) {
    createKick(ctx, out, t);
    // Snare on 2 and 4 (beat * 1, beat * 3 in 4/4)
    const measureTime = t % (beat * 4);
    if (Math.abs(measureTime - beat) < 0.05 || Math.abs(measureTime - beat * 3) < 0.05) {
      createSnare(ctx, out, t);
    }
    // Hi-hat on 8ths
    createHihat(ctx, out, t + beat / 2, 0.15);
  }

  // 2. Bass 16th-note arpeggiator
  const sixteenth = beat / 4;
  let noteIdx = 0;
  for (let t = 0; t < totalDur - 0.5; t += sixteenth) {
    const chordIndex = Math.floor((t / (beat * 4)) % chords.length);
    const root = chords[chordIndex][0];
    const oct = (noteIdx % 4 === 2) ? root * 2 : root;
    
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(oct, t);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(450, t);
    filter.frequency.exponentialRampToValueAtTime(120, t + sixteenth * 0.9);

    g.gain.setValueAtTime(0.35, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + sixteenth * 0.85);

    osc.connect(filter);
    filter.connect(g);
    g.connect(out);

    osc.start(t);
    osc.stop(t + sixteenth);
    noteIdx++;
  }

  // 3. Warm pad chords
  const measure = beat * 4;
  for (let t = 0; t < totalDur - 1; t += measure) {
    const chordIdx = Math.floor((t / measure) % chords.length);
    const chord = chords[chordIdx];

    chord.forEach((freq) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq * 1.002, t); // slight detune

      g.gain.setValueAtTime(0.001, t);
      g.gain.linearRampToValueAtTime(0.08, t + 0.6);
      g.gain.setValueAtTime(0.08, t + measure - 0.4);
      g.gain.linearRampToValueAtTime(0.001, t + measure);

      osc.connect(g);
      g.connect(out);

      osc.start(t);
      osc.stop(t + measure);
    });
  }

  // 4. Synth lead melody
  let leadT = 0;
  while (leadT < totalDur - 1) {
    const note = leadNotes[Math.floor(Math.random() * leadNotes.length)];
    const noteDur = beat * (Math.random() > 0.5 ? 1 : 2);

    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(note, leadT);

    g.gain.setValueAtTime(0.001, leadT);
    g.gain.linearRampToValueAtTime(0.12, leadT + 0.05);
    g.gain.exponentialRampToValueAtTime(0.001, leadT + noteDur - 0.05);

    osc.connect(g);
    g.connect(out);

    osc.start(leadT);
    osc.stop(leadT + noteDur);
    leadT += noteDur;
  }
}

function renderLofi(ctx: OfflineAudioContext, out: AudioNode, beat: number, totalDur: number) {
  // Jazzy mellow chords (Dmaj9, Bm7, Gmaj7, A7sus)
  const lofiChords = [
    [NOTE_FREQ.D3, NOTE_FREQ.F3 * 1.059, NOTE_FREQ.A3, NOTE_FREQ.C4 * 1.059], // Dmaj9
    [NOTE_FREQ.B2, NOTE_FREQ.D3, NOTE_FREQ.F3 * 1.059, NOTE_FREQ.A3],         // Bm7
    [NOTE_FREQ.G2, NOTE_FREQ.B2, NOTE_FREQ.D3, NOTE_FREQ.F3 * 1.059],         // Gmaj7
    [NOTE_FREQ.A2, NOTE_FREQ.D3, NOTE_FREQ.E3, NOTE_FREQ.G3],                 // A7sus
  ];

  // Gentle soft kick on beat 1 and syncopated beat 3.5
  for (let t = 0; t < totalDur; t += beat * 4) {
    createSoftKick(ctx, out, t);
    createSoftKick(ctx, out, t + beat * 2.5);
    createRimshot(ctx, out, t + beat * 2);
    createHihat(ctx, out, t + beat * 0.75, 0.08);
    createHihat(ctx, out, t + beat * 1.75, 0.08);
    createHihat(ctx, out, t + beat * 2.75, 0.08);
    createHihat(ctx, out, t + beat * 3.75, 0.08);
  }

  // Electric Rhodes chords
  const measure = beat * 4;
  for (let t = 0; t < totalDur - 1; t += measure) {
    const chord = lofiChords[Math.floor((t / measure) % lofiChords.length)];
    chord.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t + i * 0.03); // gentle strum

      g.gain.setValueAtTime(0.001, t);
      g.gain.linearRampToValueAtTime(0.18, t + 0.08);
      g.gain.exponentialRampToValueAtTime(0.015, t + measure - 0.2);
      g.gain.linearRampToValueAtTime(0.0001, t + measure);

      osc.connect(g);
      g.connect(out);

      osc.start(t);
      osc.stop(t + measure);
    });
  }

  // Ambient vinyl noise layer
  createVinylNoise(ctx, out, totalDur);
}

function renderVishSignature(ctx: OfflineAudioContext, out: AudioNode, beat: number, totalDur: number) {
  // Futuristic Spatial Electronic soundscape
  const rootScale = [NOTE_FREQ.C3, NOTE_FREQ.E3, NOTE_FREQ.G3, NOTE_FREQ.B3, NOTE_FREQ.D4, NOTE_FREQ.G4];

  // 1. Deep Sub Sine Drone
  const subOsc = ctx.createOscillator();
  const subGain = ctx.createGain();
  subOsc.type = 'sine';
  subOsc.frequency.setValueAtTime(43.65, 0); // F1 sub
  subGain.gain.setValueAtTime(0.35, 0);
  subOsc.connect(subGain);
  subGain.connect(out);
  subOsc.start(0);
  subOsc.stop(totalDur);

  // 2. Crystal shimmer arpeggios
  const step = beat / 2;
  let stepCount = 0;
  for (let t = 0; t < totalDur - 0.5; t += step) {
    const note = rootScale[stepCount % rootScale.length] * (stepCount % 8 >= 4 ? 2 : 1);
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(note, t);

    g.gain.setValueAtTime(0.001, t);
    g.gain.linearRampToValueAtTime(0.12, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t + step * 1.4);

    if (pan) {
      pan.pan.setValueAtTime(Math.sin(stepCount * 0.4), t);
      osc.connect(g);
      g.connect(pan);
      pan.connect(out);
    } else {
      osc.connect(g);
      g.connect(out);
    }

    osc.start(t);
    osc.stop(t + step * 1.5);
    stepCount++;
  }

  // 3. Cinematic Pulse every 2 beats
  for (let t = 0; t < totalDur; t += beat * 2) {
    createCinematicPulse(ctx, out, t);
  }
}

/* Drum & sound fx helper synthesizers */
function createKick(ctx: OfflineAudioContext, out: AudioNode, time: number) {
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.frequency.setValueAtTime(140, time);
  osc.frequency.exponentialRampToValueAtTime(38, time + 0.12);

  g.gain.setValueAtTime(0.65, time);
  g.gain.exponentialRampToValueAtTime(0.001, time + 0.28);

  osc.connect(g);
  g.connect(out);
  osc.start(time);
  osc.stop(time + 0.3);
}

function createSoftKick(ctx: OfflineAudioContext, out: AudioNode, time: number) {
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.frequency.setValueAtTime(95, time);
  osc.frequency.exponentialRampToValueAtTime(45, time + 0.15);

  g.gain.setValueAtTime(0.45, time);
  g.gain.exponentialRampToValueAtTime(0.001, time + 0.22);

  osc.connect(g);
  g.connect(out);
  osc.start(time);
  osc.stop(time + 0.25);
}

function createSnare(ctx: OfflineAudioContext, out: AudioNode, time: number) {
  // Tone + noise
  const osc = ctx.createOscillator();
  const oscGain = ctx.createGain();
  osc.frequency.setValueAtTime(200, time);
  osc.frequency.exponentialRampToValueAtTime(80, time + 0.1);
  oscGain.gain.setValueAtTime(0.3, time);
  oscGain.gain.exponentialRampToValueAtTime(0.001, time + 0.15);
  osc.connect(oscGain);
  oscGain.connect(out);
  osc.start(time);
  osc.stop(time + 0.18);

  // Noise burst
  createNoiseBurst(ctx, out, time, 0.18, 0.25, 1200);
}

function createRimshot(ctx: OfflineAudioContext, out: AudioNode, time: number) {
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.frequency.setValueAtTime(480, time);
  g.gain.setValueAtTime(0.2, time);
  g.gain.exponentialRampToValueAtTime(0.001, time + 0.08);
  osc.connect(g);
  g.connect(out);
  osc.start(time);
  osc.stop(time + 0.1);
}

function createHihat(ctx: OfflineAudioContext, out: AudioNode, time: number, vol = 0.1) {
  createNoiseBurst(ctx, out, time, 0.05, vol, 7000);
}

function createNoiseBurst(
  ctx: OfflineAudioContext,
  out: AudioNode,
  time: number,
  duration: number,
  volume: number,
  filterFreq: number
) {
  const bufferSize = ctx.sampleRate * duration;
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    data[i] = Math.random() * 2 - 1;
  }

  const noise = ctx.createBufferSource();
  noise.buffer = buffer;

  const filter = ctx.createBiquadFilter();
  filter.type = 'highpass';
  filter.frequency.setValueAtTime(filterFreq, time);

  const gain = ctx.createGain();
  gain.gain.setValueAtTime(volume, time);
  gain.gain.exponentialRampToValueAtTime(0.0001, time + duration);

  noise.connect(filter);
  filter.connect(gain);
  gain.connect(out);

  noise.start(time);
  noise.stop(time + duration);
}

function createCinematicPulse(ctx: OfflineAudioContext, out: AudioNode, time: number) {
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = 'sine';
  osc.frequency.setValueAtTime(65, time);
  osc.frequency.exponentialRampToValueAtTime(30, time + 0.4);

  g.gain.setValueAtTime(0.3, time);
  g.gain.exponentialRampToValueAtTime(0.001, time + 0.45);

  osc.connect(g);
  g.connect(out);
  osc.start(time);
  osc.stop(time + 0.5);
}

function createVinylNoise(ctx: OfflineAudioContext, out: AudioNode, totalDur: number) {
  const bufferSize = ctx.sampleRate * Math.min(totalDur, 5);
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    // Subtle crackle
    const isCrack = Math.random() > 0.997;
    data[i] = (Math.random() * 2 - 1) * 0.015 + (isCrack ? (Math.random() * 2 - 1) * 0.08 : 0);
  }

  const noise = ctx.createBufferSource();
  noise.buffer = buffer;
  noise.loop = true;

  const filter = ctx.createBiquadFilter();
  filter.type = 'bandpass';
  filter.frequency.setValueAtTime(1800, 0);
  filter.Q.setValueAtTime(1.2, 0);

  const g = ctx.createGain();
  g.gain.setValueAtTime(0.08, 0);

  noise.connect(filter);
  filter.connect(g);
  g.connect(out);

  noise.start(0);
  noise.stop(totalDur);
}
