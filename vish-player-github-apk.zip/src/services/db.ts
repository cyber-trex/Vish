import { Track } from '../types/music';

const DB_NAME = 'VishPlayerDB';
const DB_VERSION = 1;
const TRACKS_STORE = 'tracks';
const SETTINGS_STORE = 'settings';

export class VishDatabase {
  private db: IDBDatabase | null = null;
  private initPromise: Promise<IDBDatabase> | null = null;

  async getDB(): Promise<IDBDatabase> {
    if (this.db) return this.db;
    if (this.initPromise) return this.initPromise;

    this.initPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains(TRACKS_STORE)) {
          const trackStore = db.createObjectStore(TRACKS_STORE, { keyPath: 'id' });
          trackStore.createIndex('favorite', 'favorite', { unique: false });
          trackStore.createIndex('dateAdded', 'dateAdded', { unique: false });
        }
        if (!db.objectStoreNames.contains(SETTINGS_STORE)) {
          db.createObjectStore(SETTINGS_STORE, { keyPath: 'key' });
        }
      };

      request.onsuccess = () => {
        this.db = request.result;
        resolve(request.result);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });

    return this.initPromise;
  }

  async getAllTracks(): Promise<Track[]> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(TRACKS_STORE, 'readonly');
      const store = tx.objectStore(TRACKS_STORE);
      const req = store.getAll();

      req.onsuccess = () => {
        const tracks: Track[] = (req.result || []).map((t) => {
          // If stored as Blob, recreate object URL
          let audioUrl = t.audioUrl;
          if (t.audioBlob) {
            audioUrl = URL.createObjectURL(t.audioBlob);
          }
          return {
            ...t,
            audioUrl,
            isOffline: true,
          };
        });
        resolve(tracks);
      };

      req.onerror = () => reject(req.error);
    });
  }

  async saveTrack(track: Track): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(TRACKS_STORE, 'readwrite');
      const store = tx.objectStore(TRACKS_STORE);

      // Create a clean record for DB (strip temporary object URLs, keep Blob)
      const record = {
        ...track,
        audioUrl: undefined, // regenerate on read
        isOffline: true,
      };

      const req = store.put(record);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async saveTracks(tracks: Track[]): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(TRACKS_STORE, 'readwrite');
      const store = tx.objectStore(TRACKS_STORE);

      for (const t of tracks) {
        const record = {
          ...t,
          audioUrl: undefined,
          isOffline: true,
        };
        store.put(record);
      }

      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async deleteTrack(id: string): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(TRACKS_STORE, 'readwrite');
      const store = tx.objectStore(TRACKS_STORE);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async toggleFavorite(id: string): Promise<boolean> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(TRACKS_STORE, 'readwrite');
      const store = tx.objectStore(TRACKS_STORE);
      const getReq = store.get(id);

      getReq.onsuccess = () => {
        const track = getReq.result;
        if (!track) {
          resolve(false);
          return;
        }
        track.favorite = !track.favorite;
        const putReq = store.put(track);
        putReq.onsuccess = () => resolve(track.favorite);
        putReq.onerror = () => reject(putReq.error);
      };

      getReq.onerror = () => reject(getReq.error);
    });
  }

  async incrementPlayCount(id: string): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(TRACKS_STORE, 'readwrite');
      const store = tx.objectStore(TRACKS_STORE);
      const getReq = store.get(id);

      getReq.onsuccess = () => {
        const track = getReq.result;
        if (track) {
          track.playCount = (track.playCount || 0) + 1;
          store.put(track);
        }
        resolve();
      };
      getReq.onerror = () => resolve();
    });
  }

  async getStorageEstimate(): Promise<{ usedBytes: number; quotaBytes: number; count: number }> {
    let usedBytes = 0;
    let quotaBytes = 0;
    let count = 0;

    if (navigator.storage && navigator.storage.estimate) {
      try {
        const est = await navigator.storage.estimate();
        usedBytes = est.usage || 0;
        quotaBytes = est.quota || 0;
      } catch {
        // fallback
      }
    }

    try {
      const tracks = await this.getAllTracks();
      count = tracks.length;
      if (usedBytes === 0) {
        usedBytes = tracks.reduce((acc, t) => acc + (t.sizeBytes || 0), 0);
      }
    } catch {
      // ignore
    }

    return { usedBytes, quotaBytes, count };
  }

  async clearAllTracks(): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(TRACKS_STORE, 'readwrite');
      const store = tx.objectStore(TRACKS_STORE);
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }
}

export const dbService = new VishDatabase();
