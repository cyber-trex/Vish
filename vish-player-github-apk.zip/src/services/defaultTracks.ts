import { Track } from '../types/music';
import { synthesizeOfflineTrack, SynthPreset } from './audioSynthesizer';
import { dbService } from './db';

export const DEFAULT_PRESETS: SynthPreset[] = [
  {
    id: 'synthwave',
    title: 'Neon Horizon (Synthesized Drift)',
    artist: 'Vish Studio Audio',
    album: 'Synthetic Fragments',
    genre: 'Synthwave / Retrowave',
    bpm: 112,
    durationSec: 48,
    coverUrl: '/src/assets/images/album_neon_midnight_1792818489401.jpg',
    lyrics: [
      '[00:00.00] Atmospheric synth arpeggios rising...',
      '[00:08.50] Deep analog kick locks into groove',
      '[00:16.20] Neon lights reflection on rain-slicked streets',
      '[00:24.00] Filtered sawtooth chords swelling through the night',
      '[00:32.40] Vish sound engine modulating stereo field',
      '[00:40.00] Fading into the digital horizon...',
    ],
  },
  {
    id: 'lofi',
    title: 'Rain on Cobalt Glass',
    artist: 'Vish Ambient Lab',
    album: 'Cozy Nights, Quiet Rain',
    genre: 'Lofi Chillhop',
    bpm: 78,
    durationSec: 52,
    coverUrl: '/src/assets/images/album_lofi_rain_1792818490647.jpg',
    lyrics: [
      '[00:00.00] Soft vinyl crackle & warm Rhodes chords',
      '[00:10.00] Rain tapping against the window pane',
      '[00:20.50] Gentle rimshot and sub-bass resonance',
      '[00:31.00] Mind eases into offline contemplation',
      '[00:42.00] Warm harmonic warmth on a quiet evening',
    ],
  },
  {
    id: 'vish_signature',
    title: 'Vish Resonance (Acoustic Fusion)',
    artist: 'Vish Developing',
    album: 'Acoustic Electronic Soundscapes',
    genre: 'Spatial Ambient / Hi-Res',
    bpm: 96,
    durationSec: 45,
    coverUrl: '/src/assets/images/album_vish_signature_1792818490749.jpg',
    lyrics: [
      '[00:00.00] 43Hz sub-octave fundamental initializes',
      '[00:09.00] Crystalline stereo arpeggio dancing across channels',
      '[00:18.50] Dynamic compression balancing transient peaks',
      '[00:27.00] Vish Player graphic EQ curve shaping tone',
      '[00:36.00] Pure local client-side DSP harmony',
    ],
  },
];

export async function initializeDefaultLibrary(): Promise<Track[]> {
  try {
    const existing = await dbService.getAllTracks();
    if (existing && existing.length > 0) {
      return existing;
    }

    // Synthesize default tracks and store in IndexedDB
    const initializedTracks: Track[] = [];

    for (const preset of DEFAULT_PRESETS) {
      const audioBlob = await synthesizeOfflineTrack(preset);
      const audioUrl = URL.createObjectURL(audioBlob);

      const track: Track = {
        id: `vish-default-${preset.id}`,
        title: preset.title,
        artist: preset.artist,
        album: preset.album,
        duration: preset.durationSec,
        coverUrl: preset.coverUrl,
        audioUrl,
        audioBlob,
        isOffline: true,
        genre: preset.genre,
        bpm: preset.bpm,
        year: '2026',
        format: 'WAV',
        sizeBytes: audioBlob.size,
        dateAdded: Date.now(),
        favorite: preset.id === 'vish_signature',
        playCount: preset.id === 'synthwave' ? 3 : 1,
        lyrics: preset.lyrics,
      };

      await dbService.saveTrack(track);
      initializedTracks.push(track);
    }

    return initializedTracks;
  } catch (error) {
    console.error('Error initializing default Vish Player library:', error);
    return [];
  }
}
