import { AudioEngineStats, EQPreset } from '../types/music';

export const EQ_FREQUENCIES = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

export const EQ_PRESETS: EQPreset[] = [
  {
    name: 'Vish Signature',
    description: 'Tuned by Vish Developing: punchy low-end, crystalline stereo highs & vocal clarity',
    gains: [4, 3, 1.5, 0, 1, 2, 3, 3.5, 4, 4.5],
  },
  {
    name: 'Flat',
    description: 'Pure neutral reference studio response',
    gains: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },
  {
    name: 'Bass Boost',
    description: 'Deep sub-bass amplification for electronic and hip-hop',
    gains: [6.5, 5.5, 4, 2, 0, -1, 0, 1, 2, 2.5],
  },
  {
    name: 'Acoustic / Vocal',
    description: 'Enhanced mid-range clarity for vocalists and live instruments',
    gains: [-1, 0, 1, 2, 3.5, 4, 3.5, 2.5, 2, 1],
  },
  {
    name: 'Electronic / Club',
    description: 'High energy pump with tight bass and crisp percussive sparkle',
    gains: [5, 4, 2, 0, 1, 1.5, 2.5, 4, 5, 5.5],
  },
  {
    name: 'Rock / Live',
    description: 'Punchy rhythm guitar, snare snap, and driven low end',
    gains: [4, 3, 2, 1, -1, 1, 2.5, 3.5, 3, 3],
  },
  {
    name: 'Night / Warm',
    description: 'Mellow rolled-off treble to prevent fatigue during late night listening',
    gains: [2, 1.5, 1, 0, 0, 0, -1, -2.5, -4, -6],
  },
];

export class VishAudioEngine {
  private audio: HTMLAudioElement;
  private ctx: AudioContext | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private eqFilters: BiquadFilterNode[] = [];
  private preampGainNode: GainNode | null = null;
  private pannerNode: StereoPannerNode | null = null;
  private compressorNode: DynamicsCompressorNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private masterGainNode: GainNode | null = null;

  private eqGains: number[] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
  private preampGainVal = 0; // in dB
  private panVal = 0; // -1 to 1
  private sleepTimerId: any = null;
  private sleepEndTime: number | null = null;

  constructor() {
    this.audio = new Audio();
    this.audio.preload = 'auto';
    this.audio.crossOrigin = 'anonymous';
  }

  public getAudioElement(): HTMLAudioElement {
    return this.audio;
  }

  public initAudioContext(): AudioContext {
    if (this.ctx) return this.ctx;

    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    this.ctx = new AudioContextClass();

    // Source
    this.sourceNode = this.ctx.createMediaElementSource(this.audio);

    // Preamp
    this.preampGainNode = this.ctx.createGain();
    this.setPreampGain(this.preampGainVal);

    // 10 EQ Filters
    this.eqFilters = EQ_FREQUENCIES.map((freq, index) => {
      const filter = this.ctx!.createBiquadFilter();
      if (index === 0) {
        filter.type = 'lowshelf';
      } else if (index === EQ_FREQUENCIES.length - 1) {
        filter.type = 'highshelf';
      } else {
        filter.type = 'peaking';
        filter.Q.value = 1.4;
      }
      filter.frequency.value = freq;
      filter.gain.value = this.eqGains[index] || 0;
      return filter;
    });

    // Panner
    if (this.ctx.createStereoPanner) {
      this.pannerNode = this.ctx.createStereoPanner();
      this.pannerNode.pan.value = this.panVal;
    }

    // Mastering Compressor
    this.compressorNode = this.ctx.createDynamicsCompressor();
    this.compressorNode.threshold.value = -12;
    this.compressorNode.knee.value = 24;
    this.compressorNode.ratio.value = 3;
    this.compressorNode.attack.value = 0.005;
    this.compressorNode.release.value = 0.15;

    // Analyser Node
    this.analyserNode = this.ctx.createAnalyser();
    this.analyserNode.fftSize = 256;
    this.analyserNode.smoothingTimeConstant = 0.82;

    // Master Gain
    this.masterGainNode = this.ctx.createGain();
    this.masterGainNode.gain.value = this.audio.volume;

    // Chain: Source -> Preamp -> EQ filters -> Panner -> Compressor -> Analyser -> Master Gain -> Destination
    let prevNode: AudioNode = this.sourceNode;
    prevNode.connect(this.preampGainNode);
    prevNode = this.preampGainNode;

    for (const filter of this.eqFilters) {
      prevNode.connect(filter);
      prevNode = filter;
    }

    if (this.pannerNode) {
      prevNode.connect(this.pannerNode);
      prevNode = this.pannerNode;
    }

    prevNode.connect(this.compressorNode);
    this.compressorNode.connect(this.analyserNode);
    this.analyserNode.connect(this.masterGainNode);
    this.masterGainNode.connect(this.ctx.destination);

    return this.ctx;
  }

  public async play(): Promise<void> {
    if (!this.ctx) {
      this.initAudioContext();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }
    return this.audio.play();
  }

  public pause(): void {
    this.audio.pause();
  }

  public setSrc(url: string): void {
    if (this.audio.src !== url) {
      this.audio.src = url;
      this.audio.load();
    }
  }

  public setTime(seconds: number): void {
    if (isFinite(seconds)) {
      this.audio.currentTime = Math.max(0, Math.min(seconds, this.audio.duration || seconds));
    }
  }

  public setVolume(vol: number): void {
    const clamped = Math.max(0, Math.min(1, vol));
    this.audio.volume = clamped;
    if (this.masterGainNode && this.ctx) {
      this.masterGainNode.gain.setTargetAtTime(clamped, this.ctx.currentTime, 0.02);
    }
  }

  public setPlaybackRate(rate: number): void {
    this.audio.playbackRate = rate;
  }

  public setEQBand(index: number, gainDb: number): void {
    this.eqGains[index] = gainDb;
    if (this.eqFilters[index] && this.ctx) {
      this.eqFilters[index].gain.setTargetAtTime(gainDb, this.ctx.currentTime, 0.05);
    }
  }

  public setEQPreset(preset: EQPreset): void {
    this.eqGains = [...preset.gains];
    if (this.ctx) {
      preset.gains.forEach((gain, index) => {
        if (this.eqFilters[index]) {
          this.eqFilters[index].gain.setTargetAtTime(gain, this.ctx!.currentTime, 0.05);
        }
      });
    }
  }

  public getEQGains(): number[] {
    return [...this.eqGains];
  }

  public setPreampGain(gainDb: number): void {
    this.preampGainVal = gainDb;
    if (this.preampGainNode && this.ctx) {
      // dB to linear gain: 10^(dB / 20)
      const linear = Math.pow(10, gainDb / 20);
      this.preampGainNode.gain.setTargetAtTime(linear, this.ctx.currentTime, 0.05);
    }
  }

  public getPreampGain(): number {
    return this.preampGainVal;
  }

  public setPan(val: number): void {
    this.panVal = Math.max(-1, Math.min(1, val));
    if (this.pannerNode && this.ctx) {
      this.pannerNode.pan.setTargetAtTime(this.panVal, this.ctx.currentTime, 0.05);
    }
  }

  public getPan(): number {
    return this.panVal;
  }

  public getVisualizerData(frequencyArray: Uint8Array, timeDomainArray: Uint8Array): void {
    if (this.analyserNode) {
      this.analyserNode.getByteFrequencyData(frequencyArray as any);
      this.analyserNode.getByteTimeDomainData(timeDomainArray as any);
    }
  }

  public getStats(): AudioEngineStats {
    return {
      sampleRate: this.ctx ? this.ctx.sampleRate : 44100,
      state: this.ctx ? this.ctx.state : 'uninitialized',
      latencyHint: (this.ctx as any)?.baseLatency ? `${Math.round((this.ctx as any).baseLatency * 1000)}ms` : 'Interactive',
      channels: 2,
      eqActive: true,
      preampGain: this.preampGainVal,
      pan: this.panVal,
    };
  }

  public startSleepTimer(minutes: number, onComplete?: () => void): void {
    this.clearSleepTimer();
    const durationMs = minutes * 60 * 1000;
    this.sleepEndTime = Date.now() + durationMs;

    this.sleepTimerId = setInterval(() => {
      if (!this.sleepEndTime) return;
      const remainingMs = this.sleepEndTime - Date.now();

      // Soft fadeout during last 30 seconds
      if (remainingMs <= 30000 && remainingMs > 0 && this.masterGainNode && this.ctx) {
        const factor = Math.max(0, remainingMs / 30000);
        this.masterGainNode.gain.setTargetAtTime(this.audio.volume * factor, this.ctx.currentTime, 0.2);
      }

      if (remainingMs <= 0) {
        this.pause();
        this.clearSleepTimer();
        if (onComplete) onComplete();
      }
    }, 1000);
  }

  public clearSleepTimer(): void {
    if (this.sleepTimerId) {
      clearInterval(this.sleepTimerId);
      this.sleepTimerId = null;
    }
    this.sleepEndTime = null;
  }

  public getRemainingSleepSeconds(): number | null {
    if (!this.sleepEndTime) return null;
    const diff = Math.round((this.sleepEndTime - Date.now()) / 1000);
    return Math.max(0, diff);
  }
}

export const audioEngine = new VishAudioEngine();
