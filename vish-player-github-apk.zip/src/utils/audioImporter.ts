import { Track } from '../types/music';
import { dbService } from '../services/db';

export async function parseAudioFile(file: File): Promise<Track> {
  const extension = file.name.split('.').pop()?.toUpperCase() || 'AUDIO';
  const format: Track['format'] = ['WAV', 'MP3', 'FLAC', 'OGG', 'M4A'].includes(extension)
    ? (extension as Track['format'])
    : 'AUDIO';

  // Generate clean title & artist from filename (e.g. "Artist - Title.mp3" or "01 Track.wav")
  let cleanName = file.name.replace(/\.[^/.]+$/, '');
  let artist = 'Local Artist';
  let title = cleanName;

  if (cleanName.includes(' - ')) {
    const parts = cleanName.split(' - ');
    artist = parts[0].trim();
    title = parts.slice(1).join(' - ').trim();
  } else if (/^\d+\s*[-._]\s*/.test(cleanName)) {
    title = cleanName.replace(/^\d+\s*[-._]\s*/, '');
  }

  // Determine duration
  const audioBlob = file;
  const audioUrl = URL.createObjectURL(audioBlob);
  const duration = await getAudioDuration(audioUrl);

  // Attempt to extract ID3 cover art or generate vibrant procedural artwork
  const coverUrl = await extractOrGenerateCover(file, title, artist);

  const track: Track = {
    id: `local-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
    title,
    artist,
    album: 'Offline Local Audio',
    duration: Math.round(duration) || 180,
    coverUrl,
    audioUrl,
    audioBlob,
    isOffline: true,
    genre: 'Local Audio',
    year: new Date().getFullYear().toString(),
    format,
    sizeBytes: file.size,
    dateAdded: Date.now(),
    favorite: false,
    playCount: 0,
  };

  await dbService.saveTrack(track);
  return track;
}

function getAudioDuration(url: string): Promise<number> {
  return new Promise((resolve) => {
    const tempAudio = new Audio();
    tempAudio.preload = 'metadata';
    tempAudio.onloadedmetadata = () => {
      resolve(tempAudio.duration || 0);
    };
    tempAudio.onerror = () => {
      resolve(0);
    };
    tempAudio.src = url;
  });
}

async function extractOrGenerateCover(file: File, title: string, artist: string): Promise<string> {
  // Check for embedded ID3 APIC frame in MP3
  try {
    const buffer = await file.slice(0, 128 * 1024).arrayBuffer();
    const view = new DataView(buffer);
    
    // Check ID3v2 header
    if (view.getUint8(0) === 0x49 && view.getUint8(1) === 0x44 && view.getUint8(2) === 0x33) {
      // Basic search for JPEG or PNG magic bytes inside tag
      const bytes = new Uint8Array(buffer);
      for (let i = 10; i < bytes.length - 16; i++) {
        // JPEG magic bytes: 0xFF, 0xD8, 0xFF
        if (bytes[i] === 0xff && bytes[i + 1] === 0xd8 && bytes[i + 2] === 0xff) {
          const imgBlob = new Blob([bytes.slice(i)], { type: 'image/jpeg' });
          return URL.createObjectURL(imgBlob);
        }
        // PNG magic bytes: 0x89, 0x50, 0x4E, 0x47
        if (bytes[i] === 0x89 && bytes[i + 1] === 0x50 && bytes[i + 2] === 0x4e && bytes[i + 3] === 0x47) {
          const imgBlob = new Blob([bytes.slice(i)], { type: 'image/png' });
          return URL.createObjectURL(imgBlob);
        }
      }
    }
  } catch {
    // fallback to procedural
  }

  // Procedural canvas cover generation with stylish typography & gradient
  return generateCanvasCover(title, artist);
}

function generateCanvasCover(title: string, artist: string): string {
  const canvas = document.createElement('canvas');
  canvas.width = 400;
  canvas.height = 400;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Palette based on string hash
  const hash = (title + artist).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const hues = [240, 260, 280, 200, 320, 180, 160];
  const primaryHue = hues[hash % hues.length];
  const secondaryHue = (primaryHue + 45) % 360;

  // Background gradient
  const grad = ctx.createLinearGradient(0, 0, 400, 400);
  grad.addColorStop(0, `hsl(${primaryHue}, 65%, 16%)`);
  grad.addColorStop(0.5, `hsl(${secondaryHue}, 55%, 10%)`);
  grad.addColorStop(1, '#080c14');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 400, 400);

  // Concentric vinyl rings
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
  ctx.lineWidth = 1;
  for (let r = 40; r < 200; r += 20) {
    ctx.beginPath();
    ctx.arc(200, 200, r, 0, Math.PI * 2);
    ctx.stroke();
  }

  // Center accent glyph
  ctx.fillStyle = `hsl(${primaryHue}, 80%, 65%)`;
  ctx.beginPath();
  ctx.arc(200, 200, 24, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#080c14';
  ctx.beginPath();
  ctx.arc(200, 200, 8, 0, Math.PI * 2);
  ctx.fill();

  // Subtle border
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
  ctx.lineWidth = 2;
  ctx.strokeRect(1, 1, 398, 398);

  return canvas.toDataURL('image/jpeg', 0.88);
}
