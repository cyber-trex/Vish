export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  coverUrl: string;
  audioUrl?: string; // object URL or synthesized
  audioBlob?: Blob;
  isOffline: boolean;
  genre: string;
  bpm?: number;
  year?: string;
  format: 'WAV' | 'MP3' | 'FLAC' | 'OGG' | 'M4A' | 'AUDIO';
  sizeBytes?: number;
  dateAdded: number;
  favorite: boolean;
  playCount: number;
  lyrics?: string[];
}

export type VisualizerMode = 'bars' | 'wave' | 'circle' | 'mandala';
export type RepeatMode = 'off' | 'all' | 'one';

export interface EQPreset {
  name: string;
  description: string;
  gains: number[]; // 10 bands (-12dB to +12dB)
}

export interface AudioEngineStats {
  sampleRate: number;
  state: AudioContextState | 'uninitialized';
  latencyHint: number | string;
  channels: number;
  eqActive: boolean;
  preampGain: number;
  pan: number;
}
